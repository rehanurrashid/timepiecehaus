<?php

namespace App\Http\Controllers\Api;

use App\Country;
use App\Http\Controllers\Controller;
use App\Product;
use Illuminate\Support\Facades\DB;

class CheckoutController extends Controller
{
    public $successStatus = 200;
    public $createStatus = 201;
    public $badRequest = 400;
    public $accessForbidden = 403;
    public $serverErrorStatus = 500;
    public $notFoundStatus = 404;
    public $tokenString = 'm';

     public function getProductForCheckout($id){
         $productCheckout = DB::table('products')->select('products.id', 'products.shipping_cost','products.name', 'products.price', 'product_pictures.picture')
             ->leftjoin('product_pictures', 'products.id', '=', 'product_pictures.product_id')
             ->where('products.id', '=', $id)
             ->where('products.is_draft', '=', 0)
             ->first();
         return response()->json(['getProductForCheckout'=>$productCheckout], $this->successStatus);
     }
    public function getAllCountries()
    {
        $countries = Country::select('id', 'name')->get();
        return response()->json(['getAllCountries'=>$countries], $this->successStatus);
    }

}
