<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\ProductRating;
use App\WishList;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class WishListController extends Controller
{
    public $successStatus = 200;
    public $createStatus = 201;
    public $badRequest = 400;
    public $accessForbidden = 403;
    public $serverErrorStatus = 500;
    public $notFoundStatus = 404;
    public $tokenString = 'm';

    public function getAllWishLists()
    {
        $wishLists = DB::table('wish_lists')
            ->leftjoin('products', 'wish_lists.product_id', '=', 'products.id')
            ->leftjoin('product_pictures', 'products.id', '=', 'product_pictures.product_id')
            ->where('wish_lists.user_id', '=', auth()->id())
            ->whereNull('product_pictures.deleted_at')
            ->select('wish_lists.id as wishlist_id','wish_lists.user_id', 'products.id as product_id', 'products.name', 'products.price', 'product_pictures.picture')
            ->groupBy('wish_lists.product_id')
            ->get();
        return response()->json(['getAllWishLists'=>$wishLists], $this->successStatus);
    }
    public function addWishList(Request $request){
        $data=$request->only('product_id');
        $data['user_id']=auth()->user()->id;
        $wishlist=WishList::create($data);
         return response()->json($wishlist,$this->createStatus);
    }
}
